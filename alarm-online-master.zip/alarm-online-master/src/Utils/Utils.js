export function createArrayUnsignedInt(number){
    let array = [];

    for(var i = 0 ; i < number ; i++){
        array.push(i);
    }

    return array;
}